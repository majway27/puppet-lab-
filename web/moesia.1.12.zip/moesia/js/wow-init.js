
//WOW.js init
jQuery(function($) {
	new WOW().init();
});